import React, { useState } from "react";
import Header from "./components/Header";
import BackgroundAnimation from "./components/BackgroundAnimation";
import Introduction from "./components/Introduction";
import AboutMe from "./components/AboutMe";
import Projects from "./components/Projects";
import ContactForm from "./components/ContactForm";
import Footer from "./components/Footer";
import "./App.css";

const App = () => {
  const [language, setLanguage] = useState("en");

  const toggleLanguage = () => {
    setLanguage(prevLang => (prevLang === "en" ? "es" : "en"));
  };

  return (
    <div className="app-container">
      <Header language={language} toggleLanguage={toggleLanguage} />
      <BackgroundAnimation />
      <Introduction language={language} />
      <AboutMe language={language} />
      <Projects language={language} />
      <ContactForm language={language} />
      <Footer language={language} />
    </div>
  );
};

export default App;