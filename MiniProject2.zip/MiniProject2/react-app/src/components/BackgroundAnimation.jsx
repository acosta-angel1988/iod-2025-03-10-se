import React from "react";
import "./BackgroundAnimation.css";

const BackgroundAnimation = () => (
  <div className="wrapper">
    <div className="box">
      {[...Array(10)].map((_, i) => <div key={i}></div>)}
    </div>
  </div>
);

export default BackgroundAnimation;