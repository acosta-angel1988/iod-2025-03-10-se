import React from "react";
import "./Footer.css";

const Footer = ({ language }) => {
  
  const texts = {
    en: {
      copyright: "© 2024 Your Company. All Rights Reserved.",
    },
    es: {
      copyright: "© 2024 Tu Empresa. Todos los derechos reservados.",
    },
  };

  const t = texts[language];

  return (
    <footer className="footer">
      <br></br>
      <div className="container">
        <p>{t.copyright}</p>
        <br></br>
      </div>
    </footer>
  );
};

export default Footer;